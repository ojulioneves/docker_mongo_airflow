from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from pymongo import MongoClient

def test_mongo_connection():
    # Substitua pela URL correta do seu MongoDB
    mongo_conn_str = "mongodb://root:example@mongo:27017/admin"
    client = MongoClient(mongo_conn_str)
    
    # Listando os bancos de dados para testar a conexão
    databases = client.list_database_names()
    print(f"Databases disponíveis: {databases}")

    # Você pode adicionar uma checagem simples
    assert databases is not None, "Não foi possível listar databases no MongoDB."

default_args = {
    'start_date': datetime(2024, 1, 1),
    'catchup': False,
}

with DAG(
    dag_id='test_mongo_dag',
    default_args=default_args,
    schedule=None,  # Só roda manualmente
    tags=['test', 'mongo'],
) as dag:
    
    test_mongo = PythonOperator(
        task_id='test_mongo_connection',
        python_callable=test_mongo_connection
    )

    test_mongo
