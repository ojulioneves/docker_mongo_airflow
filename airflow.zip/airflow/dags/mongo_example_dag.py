from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from pymongo import MongoClient

def read_documents_from_admin():
    # Conexão com o MongoDB (ajuste o endereço se necessário)
    mongo_conn_str = "mongodb://root:example@mongo:27017/admin"
    client = MongoClient(mongo_conn_str)

    # Acessar o banco de dados 'admin'
    db = client['admin']

    # Acessar a coleção desejada - ajuste o nome da coleção conforme necessário
    collection_name = "teste"  # <-- Substitua pelo nome da coleção
    collection = db[collection_name]

    # Ler documentos
    documents = collection.find()

    # Printar os documentos
    for doc in documents:
        print(doc)

default_args = {
    'start_date': datetime(2024, 1, 1),
    'catchup': False,
}

with DAG(
    dag_id='read_mongo_admin_dag',
    default_args=default_args,
    schedule=None,  # Rodar manualmente
    tags=['mongo', 'read'],
) as dag:
    
    read_mongo = PythonOperator(
        task_id='read_documents_from_admin',
        python_callable=read_documents_from_admin,
    )

    read_mongo
